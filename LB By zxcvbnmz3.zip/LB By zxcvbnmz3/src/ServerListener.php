<?php

use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerTransferEvent;
use pocketmine\Server;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\{
	player\PlayerJoinEvent,
	player\PlayerDeathEvent,
	player\PlayerRespawnEvent,
	player\PlayerQuitEvent,	
	entity\EntityDamageEvent,
	entity\EntityDamageByEntityEvent
};

class ServerListener implements Listener {
	
	public function __construct(ultimate $main){
		$this->main = $main;
		}
		//on join
		public function onJoin(PlayerJoinEvent $e){
			$player  = $e->getPlayer();
			$this->addPlayerConfig($player->getName());
			}
	  //on death 
	public function onDeath(PlayerDeathEvent $e){
    $player = $e->getPlayer();
    $entity = $e->getEntity();
    if($entity->getLastDamageCause() instanceof EntityDamageByEntityEvent){
        $suck = $entity->getLastDamageCause()->getDamager(); 
        if($suck instanceof Player){ 
        } else {
            $this->addcringe($suck->getName(), 1, 'kills');
        }
    } else {
    }
    $this->addcringe($player->getName(), 1, 'death'); 
}
//save the important systems
public function addPlayerConfig($name){
  	if(!$this->main->lol->exists($name)){
  		$this->main->lol->set($name, [
  		'kills' => 0,
          'death' => 0
  		]);
  		$this->main->lol->save(true);
  	}
 }
//add points etc.
public function addcringe($n, $f, $lol){
  	$data = $this->main->lol->get($n);
  	$data[$lol] += $f;
  	$this->main->lol->set($n, $data);
  	$this->main->lol->save(true);
}
  //entity idk.
 public function slapperWtf(EntityDamageEvent $e){
  	$slapper = $e->getEntity();
  	if($e instanceof EntityDamageByEntityEvent){
  		$player = $e->getDamager();
  		if($slapper instanceof leaderSystem){
  			$e->setCancelled();
  			if($player->isOp()){
  				if($player->getItemInHand()->getId() == 352){
  					$slapper->kill();
  					return;
      					}
       				}
                   } 
                  if($slapper instanceof leaderSystem2){
  			$e->setCancelled();
  			if($player->isOp()){
  				if($player->getItemInHand()->getId() == 352){
  					$slapper->kill();
  					return;
      					}
       				}
                   } 
                   if($slapper instanceof server_info){
  			$e->setCancelled();
  			if($player->isOp()){
  				if($player->getItemInHand()->getId() == 352){
  					$slapper->kill();
  					return;
      					}
       				}
                   } 
                  if($slapper instanceof texts){
  			$e->setCancelled();
  			if($player->isOp()){
  				if($player->getItemInHand()->getId() == 352){
  					$slapper->kill();
  					return;
      					}
       				}
                   } 
              }
         }
      }