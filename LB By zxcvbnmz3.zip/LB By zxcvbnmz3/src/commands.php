<?php

use pocketmine\{Player, Server};
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class commands extends Command {
	
  public $main;
  
   public function __construct(ultimate $main){
   	  parent::__construct('ldr');
        $this->setDescription('§aUltimate LeaderBoard Command.');
        $this->setPermission("ldr.cmd");
         $this->main = $main;
   	}
  public function execute(CommandSender $sender, $label, array $args){
    if(!$this->testPermission($sender)) return false;
    
    if(isset($args[0])){
        switch(strtolower($args[0])){
            case "help":
                $sender->sendMessage("§aUltimate LeaderBoard Commands\n§e§p°§r§b /ldr spawn kills\n§e§p°§r§b /ldr spawn death\n§a===> §bCreate by mzok2k and edited by zxcvbnmz3§a <===");
                break;
            case 'spawn':
                if(isset($args[1])){
                    if(strtolower($args[1]) == "kills"){
                        $this->main->addKillEntity($sender);
                        $sender->sendMessage("§8[§aApexion§8] §asuccess spawn top kills");
                    } elseif(strtolower($args[1]) == "death"){
                        $this->main->addDeathEntity($sender);
                        $sender->sendMessage("§8[§aApexion§8] §asuccess spawn top death");
                    } elseif(strtolower($args[1]) == "serverinfo"){
                        $this->main->addInfoEntity($sender);
                        $sender->sendMessage("§8[§aApexion§8] §asuccess spawn server info");
                    } elseif(strtolower($args[1]) == "text"){
                        if(isset($args[2])){
                            $text = implode(" ", array_slice($args, 2));
                            $this->main->addTextEntity($sender, $text);
                            $sender->sendMessage("§8[§aApexion§8] §asuccess spawn text");
                        } else {
                            $sender->sendMessage("§cUsage: /ldr spawn text [text]");
                        }
                    }
                } else {
                    $sender->sendMessage("§8[§aApexion§8] §cUsage: /ldr spawn [kills|death]");
                }
                break;
        }
    } else {
        $sender->sendMessage("§8[§aApexion§8] §cUsage: /ldr [help]");
    }
    return true;
}
}