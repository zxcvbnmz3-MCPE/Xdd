<?php

use pocketmine\{Player, Server};
use pocketmine\plugin\PluginBase;
use pocketmine\command\{Command, CommandSender};
use pocketmine\event\Listener;
use pocketmine\utils\Config;
 use pocketmine\entity\Entity;

use pocketmine\nbt\tag\{
	ByteTag,
	CompoundTag,
	DoubleTag,
	ListTag,
	FloatTag,
	IntTag,
	ShortTag,
	StringTag
};
class ultimate extends PluginBase Implements Listener {
  
public static $instance = null;
  
 public $kill = [];
 
  public function onEnable(){
  	self::$instance = $this;
      Server::getInstance()->getCommandMap()->register("ldr", new commands($this));
  	$this->saveResource("setup.yml");
     $this->saveResource("leadersetup.yml");
     Server::getInstance()->getPluginManager()->registerEvents(new ServerListener($this), $this);
      $this->thing = new Config($this->getDataFolder().'leadersetup.yml', Config::YAML);
      $this->lol = new Config($this->getDataFolder().'stats.yml', Config::YAML);
		Entity::registerEntity(leaderSystem::class, true);
		Entity::registerEntity(leaderSystem2::class, true);
		Entity::registerEntity(server_info::class, true);
		Entity::registerEntity(texts::class, true);
  	}
  public static function getInstance(){
		return self::$instance;
	}
	public function center($msg){
		$args = explode("\n", $msg);
		$count = count($args);
		
		if($count <= 0){
			return $msg;
		}
		$key = 0;
		$last = 0;
		foreach($args as $n => $text){
			$len = strlen($text);
			if($len > $last){
				$last = $len;
				$key = $n;
			}
		}
		$m = "";
		for($i = 0; $i < $count; $i++){
			if($i == $key){
				$m .= $args[$i] . "\n";
				continue;
			}
			$lines = str_repeat(" ", ceil(($last - strlen($args[$i])) / 2));
			$m .= $lines . $args[$i] . $lines . "\n";
		}
		return $m;
       	}
       public function addKillEntity($sender){
		
		$x = ((int) $sender->getX()) + 0.5;
		$y = $sender->getY();
		$z = ((int) $sender->getZ()) + 0.5;
		
		$nbt = new CompoundTag ("", [
		"Pos" => new ListTag("Pos", [
		new DoubleTag("", $x),
		new DoubleTag("", $y),
		new DoubleTag("", $z)
		]),
		"Rotation" => new ListTag("Rotation", [
		new FloatTag("", $sender->getYaw()),
		new FloatTag("", $sender->getPitch())
		]),
		"Inventory" => new ListTag("Inventory", []),
		"Skin" => new CompoundTag("Skin", ["Data" => new StringTag("Data", $sender->getSkinData())]),
		
		"Health" => new ShortTag("Health", 1),
		"CustomName" => new StringTag("CustomName", ""),
		"CustomNameVisible" => new ByteTag("CustomNameVisible", 1),
		
		//"Type" => new StringTag("Type", $type)
		]);
		
		$ent = Entity::createEntity("leaderSystem", $sender->getLevel()->getChunk($x >> 4, $z >> 4), $nbt);
		$ent->spawnTo($sender);
	}
	public function addDeathEntity($sender){
		
		$x = ((int) $sender->getX()) + 0.5;
		$y = $sender->getY();
		$z = ((int) $sender->getZ()) + 0.5;
		
		$nbt = new CompoundTag ("", [
		"Pos" => new ListTag("Pos", [
		new DoubleTag("", $x),
		new DoubleTag("", $y),
		new DoubleTag("", $z)
		]),
		"Rotation" => new ListTag("Rotation", [
		new FloatTag("", $sender->getYaw()),
		new FloatTag("", $sender->getPitch())
		]),
		"Inventory" => new ListTag("Inventory", []),
		"Skin" => new CompoundTag("Skin", ["Data" => new StringTag("Data", $sender->getSkinData())]),
		
		"Health" => new ShortTag("Health", 1),
		"CustomName" => new StringTag("CustomName", ""),
		"CustomNameVisible" => new ByteTag("CustomNameVisible", 1),
		
		//"Type" => new StringTag("Type", $type)
		]);
		
		$ent = Entity::createEntity("leaderSystem2", $sender->getLevel()->getChunk($x >> 4, $z >> 4), $nbt);
		$ent->spawnTo($sender);
	}
	public function addInfoEntity($sender){
		
		$x = ((int) $sender->getX()) + 0.5;
		$y = $sender->getY();
		$z = ((int) $sender->getZ()) + 0.5;
		
		$nbt = new CompoundTag ("", [
		"Pos" => new ListTag("Pos", [
		new DoubleTag("", $x),
		new DoubleTag("", $y),
		new DoubleTag("", $z)
		]),
		"Rotation" => new ListTag("Rotation", [
		new FloatTag("", $sender->getYaw()),
		new FloatTag("", $sender->getPitch())
		]),
		"Inventory" => new ListTag("Inventory", []),
		"Skin" => new CompoundTag("Skin", ["Data" => new StringTag("Data", $sender->getSkinData())]),
		
		"Health" => new ShortTag("Health", 1),
		"CustomName" => new StringTag("CustomName", ""),
		"CustomNameVisible" => new ByteTag("CustomNameVisible", 1),
		
		//"Type" => new StringTag("Type", $type)
		]);
		
		$ent = Entity::createEntity("server_info", $sender->getLevel()->getChunk($x >> 4, $z >> 4), $nbt);
		$ent->spawnTo($sender);
	}
	public function addtextEntity($sender, $text){
		$line = str_replace("{line}", "\n", $text);
		$x = ((int) $sender->getX()) + 0.5;
		$y = $sender->getY();
		$z = ((int) $sender->getZ()) + 0.5;
		
		$nbt = new CompoundTag ("", [
		"Pos" => new ListTag("Pos", [
		new DoubleTag("", $x),
		new DoubleTag("", $y),
		new DoubleTag("", $z)
		]),
		"Rotation" => new ListTag("Rotation", [
		new FloatTag("", $sender->getYaw()),
		new FloatTag("", $sender->getPitch())
		]),
		"Inventory" => new ListTag("Inventory", []),
		"Skin" => new CompoundTag("Skin", ["Data" => new StringTag("Data", $sender->getSkinData())]),
		
		"Health" => new ShortTag("Health", 1),
		"CustomName" => new StringTag("CustomName", "{$line}"),
		"CustomNameVisible" => new ByteTag("CustomNameVisible", 1),
		
		//"Type" => new StringTag("Type", $type)
		]);
		
		$ent = Entity::createEntity("texts", $sender->getLevel()->getChunk($x >> 4, $z >> 4), $nbt);
		$ent->spawnTo($sender);
	}
	public function kills_led($type = 'kills'){
    $top = [];
    foreach($this->lol->getAll() as $name => $types){
        foreach($types as $data => $value){
            if($data == $type){
                $top[$name] = $value;
            }
        }
    }
    arsort($top);
    $i = 0;
    $msg = $this->thing->get("kill_led"); // Retrieve the correct message template
    $msg2 = $this->thing->get("kill_led2"); // Retrieve the correct message template for individual entries
    $topList = "";
    foreach($top as $name => $value){
        $i++;
        // Replace placeholders in the message template for individual entries
        $entryMsg = str_replace("{name}", $name, $msg2);
        $entryMsg = str_replace("{counts}", $i, $entryMsg);
        $entryMsg = str_replace("{kills}", $value, $entryMsg);
        // Concatenate the replaced values into $topList
        $topList .= $this->center($entryMsg);
        if($i >= 10) break;
    }
    // Replace the {top_list} placeholder in the main message template
    $msg = str_replace("{top_list}", $topList, $msg);
    $msg = str_replace("{top_count}", $i, $msg);
    return $this->center($msg);
}
public function death_led($type = 'death'){
    $top = [];
    foreach($this->lol->getAll() as $name => $types){
        foreach($types as $data => $value){
            if($data == $type){
                $top[$name] = $value;
            }
        }
    }
    arsort($top);
    $i = 0;
    $msg = $this->thing->get("death_led"); 
    $msg2 = $this->thing->get("death_led2");
    $topList = "";
    foreach($top as $name => $value){
        $i++;
        $entryMsg = str_replace("{name}", $name, $msg2);
        $entryMsg = str_replace("{counts}", $i, $entryMsg);
        $entryMsg = str_replace("{kills}", $value, $entryMsg);
        // Concatenate the replaced values into $topList
        $topList .= $this->center($entryMsg);
        if($i >= 10) break;
    }
    $msg = str_replace("{top_list}", $topList, $msg);
    $msg = str_replace("{top_count}", $i, $msg);
    return $this->center($msg);
}
public function infoserver(){
	$online = count(Server::getInstance()->getOnlinePlayers());
	$online2 = count(Server::getInstance()->getMaxPlayers());
    $msg = str_replace(["{count}", "{maxcount}"], [$online, $online2], $this->thing->get("server_info"));
    return $this->center($msg);
}
}